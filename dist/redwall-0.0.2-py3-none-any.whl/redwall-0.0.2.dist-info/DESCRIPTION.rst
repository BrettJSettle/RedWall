# RedWall

Scrape subreddits and slideshow through images or posts with a timer.  Images are cached to the temp directory currently and removing them is finicky. Don't let them pile up.


